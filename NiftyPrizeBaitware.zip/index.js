/*
IF YOU GONNA SKID JUST DO IT I DON'T GIVE A FUCK ABOUT YOUR SHIT


   Please do keep in mind that Nodejs is better then Python on discord

   Initialization
   npm install discord.js @discordjs/rest discord-api-types axios

*/



const { Client, GatewayIntentBits, Partials, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');
const axios = require('axios');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages,
    ],
    partials: [Partials.Channel],
});

const token = 'ODQ2NzgxOTI1MDc5NTE1MTg2.GAoaU9.GKdl4HGKHlMGvYinwcWY0KyKO7l9kmo0A0ULEY';

client.once('ready', () => {
    console.log('Started');
    client.guilds.cache.forEach(guild => {
        guild.commands.create({
            name: 'gen_nsfw',
            description: 'Generate NSFW Image'
        });
    });
});

client.on('interactionCreate', async interaction => {
    if (interaction.isCommand()) {
        if (interaction.commandName === 'gen_nsfw') {
            const embed = new EmbedBuilder()
                .setTitle('ระบบเจนภาพ 18+ | Generate NSFW Images')
                .setDescription('```กดปุ่มด้านล่างเพื่อทำการใช้งาน```')
                .setColor(0xf6f5f6);

            const button = new ButtonBuilder()
                .setCustomId('generate')
                .setLabel('Gen 18+')
                .setStyle(ButtonStyle.Primary);

            const row = new ActionRowBuilder()
                .addComponents(button);

            await interaction.reply({ embeds: [embed], components: [row] });
        }
    } else if (interaction.isButton()) {
        if (interaction.customId === 'generate') {
            const modal = new ModalBuilder()
                .setCustomId('generateImage')
                .setTitle('Generate NSFW Image');

            const numberInput = new TextInputBuilder()
                .setCustomId('numberInput')
                .setLabel('กรอกตัวเลขด้านล่างเพื่อทำการเจนภาพ')
                .setPlaceholder('กรุณากรอกตัวเลข')
                .setStyle(TextInputStyle.Short);

            modal.addComponents(
                new ActionRowBuilder().addComponents(numberInput)
            );

            await interaction.showModal(modal);
        }
    } else if (interaction.isModalSubmit()) {
        if (interaction.customId === 'generateImage') {
            const number = interaction.fields.getTextInputValue('numberInput');

            if (isNaN(number) || number < 1 || number > 20) {
                return interaction.reply({ content: 'โปรดป้อนตัวเลขที่ถูกต้องระหว่าง 1 ถึง 20.', ephemeral: true });
            }

            const sendingEmbed = new EmbedBuilder()
                .setTitle('Processing Request')
                .setDescription('> ```กำลังส่ง...```')
                .setColor(0xFFFF00);

            const reply = await interaction.reply({ embeds: [sendingEmbed], ephemeral: true, fetchReply: true });

            try {
                const promises = [];
                for (let i = 0; i < number; i++) {
                    promises.push(axios.get('https://api.waifu.pics/nsfw/waifu'));
                }

                const responses = await Promise.all(promises);
                const imageUrls = responses.map(response => response.data.url);

                for (const imageUrl of imageUrls) {
                    const imageEmbed = new EmbedBuilder()
                        .setTitle('Generated NSFW Image')
                        .setImage(imageUrl)
                        .setColor(0xFF5733)
                        .setFooter({ text: 'API By waifu.pics' });
                    await interaction.user.send({ embeds: [imageEmbed] });
                }

                const doneEmbed = new EmbedBuilder()
                    .setTitle('Processing Complete')
                    .setDescription('> ```ส่งให้ครบตามจำนวนที่คุณต้องการแล้วครับ !```')
                    .setColor(0x00FF00);

                await interaction.editReply({ embeds: [doneEmbed] });
            } catch (error) {
                console.error(error);
                const errorEmbed = new EmbedBuilder()
                    .setTitle('Error')
                    .setDescription('เกิดข้อผิดพลาดขณะดึงภาพ.')
                    .setColor(0xFF0000);
                await interaction.editReply({ embeds: [errorEmbed] });
            }
        }
    }
});

client.login(token);
